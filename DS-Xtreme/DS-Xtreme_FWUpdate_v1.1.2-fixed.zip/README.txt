Place update.txt and update.bin in C:\DSX\
Run Ds_Xtreme_updater_v1.2_MOD.exe
Plug in your DS-Xtreme cart
Press "Update Device"

If your card is not detected, try using a PC or VM with Windows XP
If your bottom screen goes black after loading, delete "DS-X Settings.xml" from your cart
If you are missing your apps/skin/skinapps/music folders, copy them from the "COPY TO EMPTY DS-X" folder